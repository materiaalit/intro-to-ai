package iai.nlp;

import java.util.ArrayDeque;
import java.util.Deque;
import opennlp.tools.parser.Parse;

public class Extractor {
    
    /**
     * Finds the subject of a sentence from a syntax tree. 
     * @param root root of the tree (S)
     * @return Subject as a String
     */
    public static String extractSubject(Parse root) {
        // Implement finding the subject as follows:
        // 1. Choose a root's child node with POS NP.
        // 2. Do a BFS search on the subtree of the chosen child.
        // 3. Subject is in the first found node whose POS-tag is a noun.
        // POS tags that are nouns: NN, NNP, NNS, NNPS.
        // If no noun is found, return null.
        // 
        // Useful methods in Parse objects:
        // node.getChilderen() returns Parse[] array of children
        // node.getType() returns String object of the node's POS-tag,
        // e.g. NP or VP
        // node.getCoveredText() returns the part from the original text
        // that belongs to the node
        
        Deque<Parse> queue = new ArrayDeque<>();
        for (Parse child : root.getChildren()) {
            if (child.getType().equals("NP")) {
                queue.addLast(child);
                break;
            }
        }
        
        while (!queue.isEmpty()) {
            Parse x = queue.pollFirst();
            if (x.getChildCount() > 0) {
                for (Parse child : x.getChildren()) {
                    if (child.getType().equals("NN") || child.getType().equals("NNP") ||
                        child.getType().equals("NNS") || child.getType().equals("NNPS")) {
                        return child.getCoveredText();
                    }
                    
                    queue.add(child);
                }
            }
        }

        return null;
    }
    
}
